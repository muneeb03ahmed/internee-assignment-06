**Overview**
- Recon run date: 2025-10-04 (UTC)
- Targets file: `/home/muneeb/targets_443_open.txt`
- HTTP entries (httpx): 26
- FFUF (accounts.internee.pk) total results: 4608 (most responded 403 — likely WAF)
- Packaged archive: `reports_2025-10-04_cleaned.tgz` (sha256 in corresponding `.sha256`)

**Top targets chosen for fuzzing / follow-up**
- accounts.internee.pk
- career.internee.pk
- clerk.internee.pk
- ftp.internee.pk
- hammad.internee.pk
- learn.internee.pk

**Notable findings**
- Many hosts served by Vercel/Cloudflare and Apache. Some hosts returned 302/307/308 redirects; a few 401/404.
- FFUF found many candidate paths — post-processed list in `reports/ffuf_accounts_hits_clean.txt`. A grep for likely sensitive filenames produced `reports/ffuf_accounts_sensitive_candidates.txt` (review manually).
- Nmap `ssl-cert` output saved to `reports/ssl_certs.nmap`.
- Robots & sitemaps collected to `reports/robots_sitemaps_follow.txt`.

**Recommendations / next steps**
1. Manually review `reports/ffuf_accounts_hits_clean.txt` and `reports/ffuf_accounts_sensitive_candidates.txt` for any real files (some may be false positives / blocked by WAF).
2. If permitted, re-probe selected hits with a browser (Cloudflare JS-challenge) or with authenticated requests.
3. Run targeted nuclei templates or authenticated scans for confirmed assets (only with authorization).
4. Keep the repo **private** and do not publish any credentials or private keys.


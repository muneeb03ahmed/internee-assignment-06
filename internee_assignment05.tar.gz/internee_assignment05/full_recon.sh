#!/usr/bin/env bash
set -euo pipefail
# full_recon.sh
# Usage: ./full_recon.sh
# Requirements (recommended): httpx (ProjectDiscovery), jq, nmap, ffuf, nuclei, curl, dig
# Adjust WORDLIST, TOP_N, THREADS as needed.

WORKDIR="$(pwd)"
TARGETS="$WORKDIR/targets_443_open.txt"
OUTDIR="$WORKDIR/reports"
WORDLIST=${WORDLIST:-/usr/share/wordlists/dirb/common.txt}
THREADS=${THREADS:-40}
TOP_N=${TOP_N:-6}   # number of top targets to run dirfuzz on
FFUF_AUTH="${FFUF_AUTH:-}"        # leave empty or set to "-H 'Cookie: ...'" if needed

mkdir -p "$OUTDIR"

echo "[*] Starting recon. Output -> $OUTDIR"

# Find httpx binary (prefer go install path)
find_httpx() {
  # try go env GOPATH (works even if go is not in PATH: ignore errors)
  GOPATH="$(go env GOPATH 2>/dev/null || true)"
  if [ -n "$GOPATH" ] && [ -x "$GOPATH/bin/httpx" ]; then
    printf '%s\n' "$GOPATH/bin/httpx"
    return 0
  fi

  # common installation locations
  for p in /usr/local/bin/httpx /usr/bin/httpx "$HOME/go/bin/httpx"; do
    [ -x "$p" ] && { printf '%s\n' "$p"; return 0; }
  done

  # fallback to PATH
  if command -v httpx >/dev/null 2>&1; then
    command -v httpx
    return 0
  fi

  return 1
}

if httpx_bin="$(find_httpx)"; then
  HTTPX_BIN="$httpx_bin"
  echo "[*] Using httpx -> $HTTPX_BIN"
else
  HTTPX_BIN=""
  echo "[!] httpx binary not found in GOPATH/usr/local/bin/usr/bin or PATH. Install ProjectDiscovery httpx."
fi

# 1) Enriched HTTP summary (prefer httpx JSON)
if [ -n "$HTTPX_BIN" ] && [ -x "$HTTPX_BIN" ] && command -v jq >/dev/null 2>&1; then
  echo "[*] Running httpx -> $OUTDIR/httpx_enriched.json"
  # Use the ProjectDiscovery httpx flags (no --silent, use double-dash flags)
  "$HTTPX_BIN" -l "$TARGETS" --json --status-code --title --server --ip --location --content-length --threads "$THREADS" -o "$OUTDIR/httpx_enriched.json" || echo "[!] httpx returned non-zero (check output)"
  echo "[*] Done httpx"
else
  echo "[!] httpx+jq not available. Falling back to curl headers (slower). Install httpx and jq for best results."
  OUT="$OUTDIR/httpx_enriched_fallback.txt"
  : > "$OUT"
  while IFS= read -r host; do
    [ -z "$host" ] && continue
    printf "=== %s ===\n" "$host" >> "$OUT"
    curl -sS -I -L --max-time 12 -A "Mozilla/5.0" "https://$host" 2>/dev/null | sed -n '1,20p' >> "$OUT" || echo "[curl fail] $host" >> "$OUT"
    echo >> "$OUT"
  done < "$TARGETS"
  echo "[*] Fallback headers saved -> $OUT"
fi

# The rest of your script is unchanged below; I kept your original steps but
# replaced only the broken httpx call and detection logic above.

# 2) robots.txt & sitemap.xml fetch (more polite, retries)
echo "[*] Fetching robots.txt & sitemap.xml -> $OUTDIR/robots_sitemaps_follow.txt"
: > "$OUTDIR/robots_sitemaps_follow.txt"
while IFS= read -r host; do
  [ -z "$host" ] && continue
  printf "=== %s ===\n" "$host" >> "$OUTDIR/robots_sitemaps_follow.txt"
  curl -sL --max-time 10 "https://$host/robots.txt" -o - >> "$OUTDIR/robots_sitemaps_follow.txt" || printf "[robots fail] %s\n" "$host" >> "$OUTDIR/robots_sitemaps_follow.txt"
  echo >> "$OUTDIR/robots_sitemaps_follow.txt"
  curl -sL --max-time 10 "https://$host/sitemap.xml" -o - >> "$OUTDIR/robots_sitemaps_follow.txt" || printf "[sitemap fail] %s\n" "$host" >> "$OUTDIR/robots_sitemaps_follow.txt"
  echo >> "$OUTDIR/robots_sitemaps_follow.txt"
done < "$TARGETS"

# 3) DNS quick lookup (A + CNAME)
echo "[*] Running DNS lookups (dig) -> $OUTDIR/dns_info.txt"
: > "$OUTDIR/dns_info.txt"
while IFS= read -r host; do
  [ -z "$host" ] && continue
  A="$(dig +short A "$host" | paste -s -d, - 2>/dev/null || echo "")"
  CNAME="$(dig +short CNAME "$host" | paste -s -d, - 2>/dev/null || echo "")"
  printf "%s\tA:%s\tCNAME:%s\n" "$host" "${A:--}" "${CNAME:--}" >> "$OUTDIR/dns_info.txt"
done < "$TARGETS"

# 4) TLS certificate collection using nmap (if available)
if command -v nmap >/dev/null 2>&1; then
  echo "[*] Running nmap ssl-cert script -> $OUTDIR/ssl_certs.nmap"
  nmap -iL "$TARGETS" -p 443 --script ssl-cert -oN "$OUTDIR/ssl_certs.nmap" || echo "[!] nmap ssl-cert encountered an error (still wrote output if any)."
else
  echo "[!] nmap not found; skipping ssl-cert collection. Install nmap to get certificate SANs."
fi

# 5) Basic admin/common path probe
echo "[*] Probing common admin paths (HEAD requests) -> $OUTDIR/admin_paths_head_responses.txt"
PATHS="/phpmyadmin /pma /phpmyadmin/index.php /admin /wp-admin /administrator /manager/html /login /admin/login /staging /backup /backup.zip /.git /.env"
: > "$OUTDIR/admin_paths_head_responses.txt"
while IFS= read -r host; do
  [ -z "$host" ] && continue
  for p in $PATHS; do
    status=$(curl -s -o /dev/null -w "%{http_code}" -I -L --max-time 8 "https://$host$p" || echo "000")
    printf "%s %s -> %s\n" "$host" "$p" "$status" >> "$OUTDIR/admin_paths_head_responses.txt"
  done
done < "$TARGETS"

# 6) Choose top targets for dirfuzzing:
DIR_TARGETS_FILE="$OUTDIR/ffuf_targets.txt"
: > "$DIR_TARGETS_FILE"
if [ -f "$OUTDIR/httpx_enriched.json" ] && command -v jq >/dev/null 2>&1; then
  jq -r 'select(.status_code==200) | .url' "$OUTDIR/httpx_enriched.json" | sed -E 's#https?://##' | sort -u | head -n "$TOP_N" > "$DIR_TARGETS_FILE"
else
  if [ -f "$OUTDIR/httpx_enriched_fallback.txt" ]; then
    grep -B1 -E "HTTP/1\.[01] 200|HTTP/2 200" "$OUTDIR/httpx_enriched_fallback.txt" | grep -E "=== " | sed 's/=== //; s/ ===//' | head -n "$TOP_N" > "$DIR_TARGETS_FILE" || true
  fi
fi

if [ ! -s "$DIR_TARGETS_FILE" ]; then
  echo "[*] No top 200 hosts found via httpx; defaulting to first $TOP_N hosts from targets_443_open.txt"
  head -n "$TOP_N" "$TARGETS" > "$DIR_TARGETS_FILE"
fi

echo "[*] Dirfuzz targets:"
cat "$DIR_TARGETS_FILE"

# 7) Run ffuf on each chosen target (if installed)
if command -v ffuf >/dev/null 2>&1; then
  echo "[*] Running ffuf on top targets using wordlist -> $WORDLIST"
  while IFS= read -r t; do
    [ -z "$t" ] && continue
    safe=$(echo "$t" | sed 's#https\?://##; s#/$##')
    out="$OUTDIR/ffuf_${safe//[:\/]/_}.json"
    printf "[*] ffuf -> %s (output %s)\n" "$t" "$out"
    ffuf -w "$WORDLIST" -u "https://$t/FUZZ" -mc 200,301,302,403,401 -t "$THREADS" -o "$out" -of json $FFUF_AUTH || echo "[!] ffuf failed for $t"
  done < "$DIR_TARGETS_FILE"
else
  echo "[!] ffuf not installed; skipping dirfuzz. Install ffuf to run directory discovery."
fi

# 8) Quick nuclei scan (if installed)
if command -v nuclei >/dev/null 2>&1; then
  echo "[*] Running quick nuclei templates (cves, exposures, takeovers) -> $OUTDIR/nuclei_quick.txt"
  nuclei -l "$TARGETS" -t cves/ -t exposures/ -t takeovers/ -c 20 -o "$OUTDIR/nuclei_quick.txt" || true
else
  echo "[!] nuclei not installed; skipping vulnerability templates. Install nuclei and its templates to use it."
fi

# 9) Small summary output file
SUMMARY="$OUTDIR/summary.txt"
{
  echo "Recon summary - $(date -u)"
  echo
  echo "Targets file: $TARGETS"
  echo "DNS info: $OUTDIR/dns_info.txt"
  echo "Robots & sitemaps: $OUTDIR/robots_sitemaps_follow.txt"
  echo "HTTP summary: $OUTDIR/httpx_enriched.json (or fallback file)"
  echo "SSL certs (nmap): $OUTDIR/ssl_certs.nmap"
  echo "Admin probing results: $OUTDIR/admin_paths_head_responses.txt"
  echo "FFUF results: (files with prefix $OUTDIR/ffuf_*.json)"
  echo "Nuclei quick scan: $OUTDIR/nuclei_quick.txt"
  echo
  echo "Top dirfuzz targets chosen (first $TOP_N or status==200):"
  sed -n '1,100p' "$DIR_TARGETS_FILE" 2>/dev/null || true
  echo
  echo "Notes:"
  echo "- For Cloudflare JS-challenge hosts (e.g. accounts.*), manual browser access may be required."
  echo "- Check $OUTDIR/httpx_enriched.json with jq, e.g.: jq '. | length, .[0]' $OUTDIR/httpx_enriched.json"
} > "$SUMMARY"

echo "[*] Done. Summary -> $SUMMARY"
echo "Reports are in $OUTDIR. Next suggested actions:"
echo "  - Inspect $OUTDIR/httpx_enriched.json (or fallback) to pick interesting hosts (200, server, ip)."
echo "  - Review ffuf outputs and follow up with focused fuzzing or credential tests on discovered admin pages."
echo "  - If you want, paste the httpx_enriched.json or summary here and I'll suggest exact next checks (exploit templates, takeover checks, or targeted ffuf paths)."

exit 0
